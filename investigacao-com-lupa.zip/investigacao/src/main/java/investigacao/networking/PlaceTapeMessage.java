package investigacao.networking;

import investigacao.tape.TapeService;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: pede para fixar uma fita/fio. */
public record PlaceTapeMessage(Vec3 a, Vec3 b, boolean flat, int color) {
    public static void encode(PlaceTapeMessage m, FriendlyByteBuf buf) {
        buf.writeDouble(m.a.x); buf.writeDouble(m.a.y); buf.writeDouble(m.a.z);
        buf.writeDouble(m.b.x); buf.writeDouble(m.b.y); buf.writeDouble(m.b.z);
        buf.writeBoolean(m.flat);
        buf.writeInt(m.color);
    }

    public static PlaceTapeMessage decode(FriendlyByteBuf buf) {
        Vec3 a = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        Vec3 b = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        boolean flat = buf.readBoolean();
        return new PlaceTapeMessage(a, b, flat, buf.readInt());
    }

    public static void handle(PlaceTapeMessage m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ServerPlayer p = ctx.getSender();
            if (p != null) TapeService.place(p, m.a, m.b, m.flat, m.color);
        });
        ctx.setPacketHandled(true);
    }
}

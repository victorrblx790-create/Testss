package investigacao.networking;

import investigacao.client.TapeClient;
import investigacao.tape.Tape;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: lista completa de fitas/fios da dimensão atual. */
public record SyncTapesMessage(List<Tape> tapes) {
    public static void encode(SyncTapesMessage m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.tapes.size());
        for (Tape t : m.tapes) {
            buf.writeDouble(t.a().x); buf.writeDouble(t.a().y); buf.writeDouble(t.a().z);
            buf.writeDouble(t.b().x); buf.writeDouble(t.b().y); buf.writeDouble(t.b().z);
            buf.writeBoolean(t.flat());
            buf.writeInt(t.color());
        }
    }

    public static SyncTapesMessage decode(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<Tape> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            Vec3 a = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
            Vec3 b = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
            boolean flat = buf.readBoolean();
            list.add(new Tape(a, b, flat, buf.readInt()));
        }
        return new SyncTapesMessage(list);
    }

    public static void handle(SyncTapesMessage m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> TapeClient.receive(m.tapes)));
        ctx.setPacketHandled(true);
    }
}

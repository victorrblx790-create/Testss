package investigacao.client;

import investigacao.Investigacao;
import investigacao.items.LupaItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Lente da Lupa: sem tela/GUI. Ao segurar o botão direito, a câmera dá zoom e
 * aparece a moldura preta quadrada com janela transparente. Roda do mouse ajusta o zoom.
 * Código original (não derivado de Inspector/Detective).
 */
public final class LupaClient {
    private static final float MIN_ZOOM = 2f, MAX_ZOOM = 8f, DEFAULT_ZOOM = 4f;
    private static float target = DEFAULT_ZOOM; // zoom escolhido
    private static float current = 1f;          // zoom suavizado aplicado

    private LupaClient() {}

    private static boolean usingLupa(Player p) {
        return p != null && p.isUsingItem() && p.getUseItem().getItem() instanceof LupaItem;
    }

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            // abaixo da hotbar: a hotbar continua visível por cima da moldura
            e.registerBelow(VanillaGuiOverlay.HOTBAR.id(), "lupa_moldura", LupaClient::drawFrame);
        }
    }

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            boolean on = usingLupa(Minecraft.getInstance().player);
            if (!on) target = DEFAULT_ZOOM;
            current = Mth.lerp(0.35f, current, on ? target : 1f);
            if (Math.abs(current - 1f) < 0.01f) current = 1f;
        }

        @SubscribeEvent
        public static void fov(ComputeFovModifierEvent e) {
            if (current > 1f) e.setNewFovModifier(e.getNewFovModifier() / current);
        }

        @SubscribeEvent
        public static void scroll(InputEvent.MouseScrollingEvent e) {
            if (!usingLupa(Minecraft.getInstance().player)) return;
            target = Mth.clamp(target + (float) Math.signum(e.getScrollDelta()), MIN_ZOOM, MAX_ZOOM);
            e.setCanceled(true); // não troca o slot da hotbar
        }

        @SubscribeEvent
        public static void hand(RenderHandEvent e) {
            if (usingLupa(Minecraft.getInstance().player)) e.setCanceled(true); // moldura cobre a mão
        }
    }

    /** Moldura: anel preto quadrado (~86% da altura), janela ~62% do anel, chanfro nos lados direito/inferior. */
    private static void drawFrame(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        if (!usingLupa(Minecraft.getInstance().player) || current < 1.05f) return;
        float k = Mth.clamp((current - 1f) / (target - 1f), 0f, 1f); // abre junto com o zoom
        int outer = Math.round(h * 0.86f * (0.8f + 0.2f * k));
        int hole = Math.round(outer * 0.62f);
        int x0 = (w - outer) / 2, y0 = (h - outer) / 2;
        int hx0 = (w - hole) / 2, hy0 = (h - hole) / 2, hx1 = hx0 + hole, hy1 = hy0 + hole;
        int black = 0xFF050505, bevel = 0xFF1C1C1C;
        g.fill(x0, y0, x0 + outer, hy0, black);              // topo
        g.fill(x0, hy1, x0 + outer, y0 + outer, black);      // base
        g.fill(x0, hy0, hx0, hy1, black);                    // esquerda
        g.fill(hx1, hy0, x0 + outer, hy1, black);            // direita
        int b = Math.max(2, outer / 14);                     // chanfro interno
        g.fill(hx1, hy0, hx1 + b, hy1 + b, bevel);
        g.fill(hx0, hy1, hx1 + b, hy1 + b, bevel);
    }
}

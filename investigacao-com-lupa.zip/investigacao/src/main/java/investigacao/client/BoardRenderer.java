package investigacao.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import investigacao.block.BoardBlock;
import investigacao.block.BoardBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Desenha as fotografias no quadro (3x3) usando o renderizador de itens, no modo "moldura" (FIXED). */
public class BoardRenderer implements BlockEntityRenderer<BoardBlockEntity> {
    private static final float CELL = 0.3f;
    private static final float SCALE = 0.56f;

    @Override
    public void render(BoardBlockEntity be, float partialTick, PoseStack ps, MultiBufferSource buffer,
                       int light, int overlay) {
        if (be.getLevel() == null) return;
        Direction facing = be.getBlockState().getValue(BoardBlock.FACING);
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - facing.toYRot()));
        // frente do painel fica em z = +0.375 (local); fotos um pouco à frente, olhando para -Z
        ps.translate(0, 0, 0.365);
        for (int i = 0; i < BoardBlockEntity.SLOTS; i++) {
            ItemStack stack = be.photos().get(i);
            if (stack.isEmpty()) continue;
            int col = i % 3, row = i / 3;
            ps.pushPose();
            ps.translate(-(col - 1) * CELL, (1 - row) * CELL, 0);
            ps.scale(SCALE, SCALE, SCALE);
            Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.FIXED,
                    light, OverlayTexture.NO_OVERLAY, ps, buffer, be.getLevel(), (int) be.getBlockPos().asLong() + i);
            ps.popPose();
        }
        ps.popPose();
    }
}

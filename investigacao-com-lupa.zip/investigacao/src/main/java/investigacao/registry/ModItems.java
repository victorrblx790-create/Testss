package investigacao.registry;

import investigacao.Investigacao;
import investigacao.items.LupaItem;
import investigacao.items.TapeItem;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Investigacao.MOD_ID);

    /** Cores dos 16 tingimentos do Minecraft. */
    private static final Object[][] COLORS = {
        {"white", 0xF9FFFE}, {"orange", 0xF9801D}, {"magenta", 0xC74EBD}, {"light_blue", 0x3AB3DA},
        {"yellow", 0xFED83D}, {"lime", 0x80C71F}, {"pink", 0xF38BAA}, {"gray", 0x474F52},
        {"light_gray", 0x9D9D97}, {"cyan", 0x169C9C}, {"purple", 0x8932B8}, {"blue", 0x3C44AA},
        {"brown", 0x835432}, {"green", 0x5E7C16}, {"red", 0xB02E26}, {"black", 0x1D1D21}
    };

    public static final RegistryObject<Item> TAPE =
            ITEMS.register("faixa_isolamento", () -> new TapeItem(new Item.Properties().stacksTo(1), -1));

    public static final Map<String, RegistryObject<Item>> SPOOLS = new LinkedHashMap<>();
    static {
        for (Object[] c : COLORS) {
            String name = (String) c[0];
            int rgb = (Integer) c[1];
            SPOOLS.put(name, ITEMS.register(name + "_thread_spool",
                    () -> new TapeItem(new Item.Properties().stacksTo(1), rgb)));
        }
    }


    public static final RegistryObject<Item> LUPA =
            ITEMS.register("lupa", () -> new LupaItem(new Item.Properties()));

    public static final RegistryObject<Item> BOARD_ITEM =
            ITEMS.register("investigation_board", () -> new BlockItem(ModBlocks.BOARD.get(), new Item.Properties()));

    private ModItems() {}
}

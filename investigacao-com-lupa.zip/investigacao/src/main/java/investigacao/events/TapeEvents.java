package investigacao.events;

import com.mojang.brigadier.Command;
import investigacao.Investigacao;
import investigacao.tape.TapeService;
import investigacao.tape.TapeStore;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Investigacao.MOD_ID)
public final class TapeEvents {
    private TapeEvents() {}

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent e) { TapeStore.load(e.getServer()); }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) { TapeStore.save(e.getServer()); }

    @SubscribeEvent
    public static void onLevelSave(LevelEvent.Save e) {
        if (e.getLevel() instanceof ServerLevel sl) TapeStore.save(sl.getServer());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) TapeService.sync(p);
    }

    @SubscribeEvent
    public static void onChangeDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) TapeService.sync(p);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("faixa")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("limpar").executes(c -> {
                    ServerLevel w = c.getSource().getLevel();
                    TapeStore.clear(TapeService.dim(w));
                    TapeService.broadcast(w);
                    c.getSource().sendSuccess(() -> Component.literal("Faixas desta dimensão removidas."), true);
                    return Command.SINGLE_SUCCESS;
                })));
    }
}

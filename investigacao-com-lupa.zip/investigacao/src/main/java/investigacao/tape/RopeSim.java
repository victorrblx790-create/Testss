package investigacao.tape;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Corda de verlet (port fiel do original Fabric):
 * 32 segmentos, 14 iterações, gravidade 0.006, amortecimento 0.972,
 * colisão com blocos (raio do ponto), "sono" quando para de se mexer.
 */
public final class RopeSim {
    public static final int SEG = 32;
    public static final int POINTS = SEG + 1;
    private static final int ITERS = 14;
    private static final double GRAVITY = 0.006;
    private static final double DAMPING = 0.972;
    private static final double RADIUS = 0.04;
    private static final double BIAS = 0.0025;
    private static final double SLEEP_V2 = 1.0E-6;
    private static final double ANCHOR_DELTA = 0.0025;
    private static final int SLEEP_TICKS = 12;
    private static final double SLACK = 1.04;

    public final double[] x = new double[POINTS], y = new double[POINTS], z = new double[POINTS];
    private final double[] px = new double[POINTS], py = new double[POINTS], pz = new double[POINTS];
    private double rest;
    private int calm;
    private boolean sleeping;
    private Vec3 lastA, lastB;

    public RopeSim(Vec3 a, Vec3 b) {
        lastA = a;
        lastB = b;
        rest = Math.max(a.distanceTo(b) * SLACK / SEG, 0.04);
        for (int i = 0; i < POINTS; i++) {
            double t = i / (double) SEG;
            x[i] = Mth.lerp(t, a.x, b.x);
            y[i] = Mth.lerp(t, a.y, b.y) - Math.sin(Math.PI * t) * 0.08;
            z[i] = Mth.lerp(t, a.z, b.z);
            px[i] = x[i]; py[i] = y[i]; pz[i] = z[i];
        }
    }

    public void update(Level w, Vec3 a, Vec3 b) {
        if (a.distanceTo(lastA) > ANCHOR_DELTA || b.distanceTo(lastB) > ANCHOR_DELTA) {
            sleeping = false;
            calm = 0;
        }
        lastA = a;
        lastB = b;
        rest = Math.max(a.distanceTo(b) * SLACK / SEG, 0.04);
        if (sleeping) return;

        double maxV = 0;
        for (int i = 1; i < SEG; i++) {
            double vx = (x[i] - px[i]) * DAMPING;
            double vy = (y[i] - py[i]) * DAMPING;
            double vz = (z[i] - pz[i]) * DAMPING;
            px[i] = x[i]; py[i] = y[i]; pz[i] = z[i];
            x[i] += vx;
            y[i] += vy - GRAVITY;
            z[i] += vz;
            maxV = Math.max(maxV, vx * vx + vy * vy + vz * vz);
        }
        pin(a, b);
        for (int it = 0; it < ITERS; it++) {
            constrain();
            pin(a, b);
            if ((it & 1) == 1) collide(w);
        }
        pin(a, b);

        if (maxV < SLEEP_V2) {
            if (++calm >= SLEEP_TICKS) sleeping = true;
        } else {
            calm = 0;
        }
    }

    private void pin(Vec3 a, Vec3 b) {
        x[0] = px[0] = a.x; y[0] = py[0] = a.y; z[0] = pz[0] = a.z;
        x[SEG] = px[SEG] = b.x; y[SEG] = py[SEG] = b.y; z[SEG] = pz[SEG] = b.z;
    }

    private void constrain() {
        for (int i = 0; i < SEG; i++) {
            double dx = x[i + 1] - x[i], dy = y[i + 1] - y[i], dz = z[i + 1] - z[i];
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz) + 1.0E-12;
            double corr = (dist - rest) / dist;
            double wa = i == 0 ? 0 : 1, wb = i + 1 == SEG ? 0 : 1;
            double sum = wa + wb;
            if (sum == 0) continue;
            x[i] += dx * corr * wa / sum; y[i] += dy * corr * wa / sum; z[i] += dz * corr * wa / sum;
            x[i + 1] -= dx * corr * wb / sum; y[i + 1] -= dy * corr * wb / sum; z[i + 1] -= dz * corr * wb / sum;
        }
    }

    private void collide(Level w) {
        for (int i = 1; i < SEG; i++) {
            boolean hit = false;
            AABB pb = new AABB(x[i] - RADIUS, y[i] - RADIUS, z[i] - RADIUS, x[i] + RADIUS, y[i] + RADIUS, z[i] + RADIUS);
            for (BlockPos bp : BlockPos.betweenClosed(
                    Mth.floor(pb.minX), Mth.floor(pb.minY), Mth.floor(pb.minZ),
                    Mth.floor(pb.maxX), Mth.floor(pb.maxY), Mth.floor(pb.maxZ))) {
                VoxelShape shape = w.getBlockState(bp).getCollisionShape(w, bp);
                if (shape.isEmpty()) continue;
                for (AABB local : shape.toAabbs()) {
                    AABB bb = local.move(bp);
                    if (!bb.intersects(pb)) continue;
                    double[] ov = {pb.maxX - bb.minX, bb.maxX - pb.minX, pb.maxY - bb.minY,
                            bb.maxY - pb.minY, pb.maxZ - bb.minZ, bb.maxZ - pb.minZ};
                    int m = 0;
                    for (int k = 1; k < 6; k++) if (ov[k] < ov[m]) m = k;
                    double s = ov[m] + BIAS;
                    switch (m) {
                        case 0 -> x[i] -= s;
                        case 1 -> x[i] += s;
                        case 2 -> y[i] -= s;
                        case 3 -> y[i] += s;
                        case 4 -> z[i] -= s;
                        default -> z[i] += s;
                    }
                    hit = true;
                    pb = new AABB(x[i] - RADIUS, y[i] - RADIUS, z[i] - RADIUS, x[i] + RADIUS, y[i] + RADIUS, z[i] + RADIUS);
                }
            }
            if (hit) { // amortece o ponto que encostou
                px[i] = x[i] + (px[i] - x[i]) * 0.25;
                py[i] = y[i] + (py[i] - y[i]) * 0.25;
                pz[i] = z[i] + (pz[i] - z[i]) * 0.25;
            }
        }
    }
}

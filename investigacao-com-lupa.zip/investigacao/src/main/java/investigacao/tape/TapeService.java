package investigacao.tape;

import investigacao.items.TapeItem;
import investigacao.networking.ModNetwork;
import investigacao.networking.SyncTapesMessage;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Lógica de servidor: validação, colocação e sincronização. */
public final class TapeService {
    /** Distância máxima entre os dois pontos (a textura cobre ~24 blocos de corda). */
    public static final double MAX_LEN = 20.0;

    private TapeService() {}

    public static String dim(ServerLevel w) { return w.dimension().location().toString(); }

    public static boolean holds(net.minecraft.world.entity.player.Player p, int color) {
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            if (s.getItem() instanceof TapeItem t && t.color() == color) return true;
        }
        return false;
    }

    public static void place(ServerPlayer p, Vec3 a, Vec3 b, boolean flat, int color) {
        if (!holds(p, color)) return;
        double len = a.distanceTo(b);
        if (!(len >= 0.3 && len <= MAX_LEN + 0.5)) return; // também rejeita NaN
        if (p.getEyePosition().distanceTo(b) > 12.0 || p.getEyePosition().distanceTo(a) > 40.0) return;
        ServerLevel w = p.serverLevel();
        TapeStore.add(dim(w), new Tape(a, b, flat, color));
        broadcast(w);
    }

    public static void sync(ServerPlayer p) {
        List<Tape> copy = List.copyOf(TapeStore.get(dim(p.serverLevel())));
        ModNetwork.sendTo(p, new SyncTapesMessage(copy));
    }

    public static void broadcast(ServerLevel w) {
        for (ServerPlayer p : w.players()) sync(p);
    }
}

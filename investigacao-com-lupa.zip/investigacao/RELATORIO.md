# Investigação — relatório de estado (etapa 2: Faixa portada + Exposure/Polaroid embutidos)

**Estado: parcial. NÃO há `investigacao-1.0.0.jar`. Nada foi compilado nem executado.**

## 1. Inventário verificado (pelos metadados dos JARs e pelo código-fonte)
| Componente | Loader / MC | Licença declarada | Fonte no pacote |
|---|---|---|---|
| Exposure 1.9.24 | Forge 1.20.1 | MIT | não (só binário) |
| Exposure Polaroid 1.1.4 | Forge 1.20.1 | MIT | não (só binário) |
| Exposure Detective 1.1.0 | NeoForge 1.21.1 | All Rights Reserved | não (55 classes) |
| Faixa de Isolamento | Fabric 1.21.8 | não declarada no pacote | sim |

Detective (nomes de classe e recursos listados no JAR): BoardBlock/BoardBlockEntity (quadro com fotos e fios),
RedStringItem/ColoredStringItem/RgbThreadSpoolItem, InkItem + tinta invisível, MagnifierItem,
DetectiveHatItem, sistema de desenho em fotos (DrawingStorage/Codec/Raster) com 6 payloads de rede,
mixins no renderer de fotografias do Exposure. Isto é só o que os nomes mostram; comportamento não analisado.

## 2. Feito (código escrito, NÃO compilado)
Port da Faixa para Forge 1.20.1 (mappings oficiais), em `src/main/java/investigacao/`:
item, RopeSim (constantes preservadas: 32 seg., 14 iter., g=0.006, amort. 0.972, colisão com blocos,
sono), posicionamento em 2 pontos, cancelamento (agachar + clicar no ar), persistência
(`faixas_isolamento.txt`, mesmo formato), rede SimpleChannel (place C→S, sync S→C), sincronização no
login/troca de dimensão, comando `/faixa limpar`, renderização (RenderLevelStageEvent), textura e modelo originais.

Adaptações necessárias: Fabric API → eventos Forge; payloads → SimpleChannel; item model JSON 1.20.1;
`RenderLayer`/`VertexConsumer` → API 1.20.1 (`uv/overlayCoords/uv2/normal/endVertex`).

## 3. Não feito
- **Exposure / Polaroid**: MIT permite incorporar/modificar com aviso de copyright, mas só há binários. Para
  fundir de verdade no modId `investigacao` é preciso o código-fonte (GitHub dos autores, mortuusars). Sem rede aqui.
- **Detective**: licença All Rights Reserved. Não decompilei nem reproduzi nada. Opções: autorização do autor
  (MineBlock1305) + fonte, ou reimplementação independente (clean-room) a partir de uma especificação funcional sua.
- Gradle wrapper (`gradlew`) ausente: precisa de rede para gerar.

## 4. Testes
Nenhum executado. Ambiente: sem rede, sem Gradle/Forge/MDK, só JRE 21 (sem `javac`), sem Minecraft.
Versão do Forge (`47.3.0`) e do ForgeGradle no `build.gradle` vêm da minha memória e não foram verificadas.

## 5. Para compilar na sua máquina (JDK 17 + internet)
`gradle wrapper --gradle-version 8.1.1` (ou copie o wrapper de um MDK 1.20.1) → `./gradlew clean build`.
Envie o log de erros que eu corrijo.

## Atualização — Exposure e Polaroid embutidos (MIT)
- Os dois JARs originais estão em `libs/originais/` e entram **sem alteração** no JAR final pela tarefa Gradle `mergedJar`
  (câmera, modelos, texturas, sons, receitas e lógica originais).
- O `mods.toml` único declara 3 mods dentro de 1 JAR: `investigacao`, `exposure`, `exposure_polaroid`.
  Os modIds do Exposure/Polaroid **não foram renomeados** (renomear bytecode sem fonte é de alto risco).
- Detective **não** está incluído (All Rights Reserved).
- Não verificado: a montagem do JAR, se o Forge carrega os 3 mods juntos, e se o `reobfJar` convive com as classes
  já reofuscadas. Os dois MixinExtras embutidos têm hashes diferentes; mantive o do Exposure.
- Rodar `runClient` no Gradle NÃO carrega Exposure/Polaroid (são binários reofuscados); teste instalando o JAR final.
- Falta o texto da licença MIT com o copyright dos autores (ver NOTICE-THIRD-PARTY.md).

## Atualização — Detective independente + quadro com fotos do Polaroid
O Exposure Detective original (All Rights Reserved) NÃO foi copiado, decompilado nem incluído. Escrevi do zero, só a partir
da lista de funções (texturas são placeholders gerados por código):
- 16 carretéis de linha colorida: clique em dois pontos para esticar um fio (mesma física da faixa; persistência e multiplayer).
  Receita: linha + corante.
- Quadro de Investigação (bloco): clique direito com uma fotografia do Exposure/Polaroid fixa a foto (até 9, grade 3x3);
  agachado com a mão vazia retira a última; ao quebrar, as fotos caem. Receita: tábuas ao redor de papel.
  As fotos são reconhecidas pelos IDs `exposure:photograph`, `exposure:aged_photograph` e `exposure:stacked_photographs`
  (nomes lidos do lang do Exposure; sem dependência de código). O `mods.toml` exige exposure e exposure_polaroid.
- Comando `/faixa limpar` remove faixas e fios da dimensão.
Risco conhecido: as fotos são desenhadas no quadro pelo renderizador de itens (modo FIXED). Não sei se o Exposure desenha a
imagem da foto nesse modo (ele usa mixins próprios); se aparecer só o papel, preciso ver o log/print para ajustar.
Não implementados: tintas/tinta invisível e desenho sobre fotografias do Detective original.
Nada foi compilado ou testado no jogo.

## Etapa 3 — Lupa (original, sem GUI)
Adicionados: `items/LupaItem`, `client/LupaClient`, registro `investigacao:lupa`, modelo (mão 3D preta + ícone 2D via `forge:separate_transforms`), receita, lang pt/en.
Funcionamento: segurar botão direito = zoom (FOV/4 suavizado), moldura preta quadrada com janela, roda do mouse = zoom 2x–8x, mão escondida.
Código/texturas escritos do zero: NÃO copiam Inspector nem Exposure Detective (ambos All Rights Reserved). Não compilado (sem JDK/rede aqui).
O projeto já era Forge 1.20.1 (47.3.0); nenhuma migração de versão foi necessária.
